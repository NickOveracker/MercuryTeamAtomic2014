(defproject jinput "0.0.1"
  :description "64bit and 32bit native Jinput binaries and jar for multiple platforms - OSX, Linux & Windows")
